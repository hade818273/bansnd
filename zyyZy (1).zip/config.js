module.exports = {
  bot: {
    owners: ["948386383502901249"],  // ايدي الاونر
    botID: "1035662460729958510",    // ايدي البوت
    GuildId: "1081974415316746400",   // ايدي السيرفير
    ClientId: "1035662460729958510",    // ايدي البوت
    serverinvte: "https://discord.gg/YfJaGyPu5W", // انفايت سيرفر
    clientSECRET: process.env.client , // سكريت
    callbackURL: "https://vanilla-momentous-swan.glitch.me/login", // الكال باك
    inviteBotUrl: "https://discord.com/oauth2/authorize?client_id=1035662460729958510&permissions=8&scope=bot",// انفايت البوت
    TheLinkVerfy : 'https://discord.com/oauth2/authorize?client_id=1035662460729958510&response_type=code&redirect_uri=+https%3A%2F%2Fvanilla-momentous-swan.glitch.me%2Flogin&scope=identify+email+guilds+guilds.join', // رابط اوثو رايز بالصلاحيه ادخال الي سيرفرات
    prefix : '$', 
    ceatogry : '1116853350009405512', // كاتوجري الي يفتح فيها تكت شراء
     TOKEN: (process.env.midd),// توكن 
    Price: 2000,    // سعر العضو الواحد
    TraId  : '948386383502901249' // ايدي الي يتحوله كريديت
  },
  website: {
    PORT: "3001",
  }
}